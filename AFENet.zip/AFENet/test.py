##### System library #####
import codecs
import csv
import os
import argparse
import time
from datetime import datetime
import tqdm
import socket
import numpy as np
from PIL import Image
import utils
##### pytorch library #####
import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
##### My own library #####
from dataprepare.dataloader import Yuanyuan_loader
from utils.loss import loss_builder
import utils.utils as u
from config import DefaultConfig
import utils
from models.Net import Res34UNet,ResNet34_DsSE,ResNet34_MsFF,AFENet

torch.multiprocessing.set_start_method('spawn')
net_work = 'AFENet'

def test(args, model, dataloader, checkpoint):
    print('start test!')
    model.load_state_dict(checkpoint['state_dict'])
    with torch.no_grad():
        model.eval()  # 测试模式，自动把BN和DropOut固定住，不会取平均，而是用训练好的值
        # 仅预测结果，不计算指标
        tq = tqdm.tqdm(dataloader, desc='\r')
        tq.set_description('test')  # 进度条及前缀
        total_Dice0 = [[]]# total_Dice中包含2个类别的dice列表
        total_PC=[]
        total_SE=[]
        total_SP=[]
        total_JS=[]
        total_PCC=[]
        total_Acc = []

        cur_predict_cube = []
        cur_label_cube = []
        counter = 0
        end_flag = False

        for i, (data, labels) in enumerate(tq):
            if torch.cuda.is_available() and args.use_gpu:
                data = data.cuda()
                label = labels[0].cuda()  # val模式下labels返回一个元祖，[0]为tensor,bnhw，[1]为cube中包含slice张数int值20
            slice_num =args.test_batch_size
            # get RGB predict image
            predict = model(data)
            predict[predict<0.5]=0
            predict[predict>0.5]=1
            batch_size = predict.size()[0]  # 即n
            counter += batch_size
            if counter <= slice_num:  # cube拼接
                cur_predict_cube.append(predict)
                cur_label_cube.append(label)
                if counter == slice_num:  # slice_num整除batch_size
                    end_flag = True
                    counter = 0  # counter清0，开始下一个cube计数
            else:  # slice_num不能整除batch_size
                last = batch_size - (counter - slice_num)  # 当前batch size中有last张属于当前处理的cube
                last_p = predict[0:last]  # 属于当前处理的cube的预测和标签
                last_l = label[0:last]
                first_p = predict[last:]  # 属于下一个cube的预测和标签
                first_l = label[last:]
                cur_predict_cube.append(last_p)  # 当前处理的cube拼接
                cur_label_cube.append(last_l)
                end_flag = True
                counter = counter - slice_num  # counter累计到下一个cube的值

            if end_flag:  # 拼接完成，end_flag为True
                end_flag = False
                label_cube = torch.cat(cur_label_cube, dim=0)
                predict_cube = torch.cat(cur_predict_cube, dim=0)  # 在0维拼接，列表转为slice_num*h*w的tensor

                cur_predict_cube = []  # 当前处理的cube列表清空
                cur_label_cube = []
                if counter != 0:  # 处理累计到下一个cube的slice
                    cur_predict_cube.append(first_p)
                    cur_label_cube.append(first_l)

                assert len(args.cuda.split(',')) * predict_cube.size()[0] == slice_num
                Dice, true_label, Acc = u.eval_single_seg(predict_cube, label_cube,args.num_classes)  # 返回Dice列表, True_label列表中包含2个类别的像素数量，acc为标量值
                PCC = u.compute_PCC(predict_cube, label_cube)
                PC, SE, Jaccard, SP = u.compute_score(predict_cube, label_cube,n_class=args.num_classes)  #注意修改

                class_id=0
                total_Dice0[class_id].append(Dice[class_id])
                total_SE.append(SE)
                total_PC.append(PC)
                total_JS.append(Jaccard)
                total_SP.append(SP)
                #total_F1[class_id].append(F1[class_id])
                total_PCC.append(PCC)# 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                total_Acc.append(Acc)

                len0 = len(total_Dice0[0]) if len(total_Dice0[0]) != 0 else 1
                dice = sum(total_Dice0[0]) / len0
                se0 = sum(total_SE) / len(total_SE)
                pc0 = sum(total_PC) / len(total_PC)
                sp0 = sum(total_SP) / len(total_SP)
                js0 = sum(total_JS) / len(total_JS)
                # f10 = sum(total_F1[0]) / len(total_SP[0])
                pcc0 = sum(total_PCC) / len(total_PCC)
                acc = sum(total_Acc) / len(total_Acc)
                tq.set_description(
                    ' Dice: %.3f, Acc: %.3f, SE0:%.3f,  SP0:%.3f, JS0: %.3f, PC0: %.3f' % (
                    dice, acc,se0,sp0,js0,pc0))
    return dice,acc,se0,sp0,js0,pc0,pcc0

def main(mode='test', args=None, checkpoint=None):
    # create dataset and dataloader
    dataset_path = os.path.join(args.data, args.dataset)
    dataset_val = Yuanyuan_loader(dataset_path,scale=(args.crop_height, args.crop_width), mode='test')
    dataloader_test = DataLoader(
        dataset_val,
        # this has to be 1
        batch_size=1,  # 只选择1块gpu，batchsize=1
        shuffle=False,
        num_workers=0,
        pin_memory=True,
        drop_last=False
    )
    model = AFENet()
    print('Model have been loaded!,you chose the ' + net_work + '!')
    if torch.cuda.is_available() and args.use_gpu:
        model = torch.nn.DataParallel(model).cuda()  # torch.nn.DataParallel是支持并行GPU使用的模型包装器，并将模型放到cuda上
    print("=> loading trained model '{}'".format(args.trained_model_path))
    if mode == 'test':
        Dice,  Acc , Sensitivity, Specificity,jaccard, PC, PCC = test(args, model, dataloader_test, checkpoint=checkpoint)
        index = ['{}'.format(net_work),Dice,  Acc , Sensitivity, Specificity,jaccard, PC, PCC]
#        path = 'test_result/{}/'.format(net_work)
#        if not os.path.exists(path):
#            os.makedirs(path)
        path_csv = 'test_result/{}.csv'.format(net_work)
        file_path = codecs.open(path_csv,'w+','utf-8')
        mywrite = csv.writer(file_path)
        mywrite.writerow(index)
        file_path.close()
        print('sucessful!!!')

if __name__ == '__main__':
    args = DefaultConfig()  # 配置设置
    # set gpu
    print("args.cuda ======== {}".format(args.cuda))
    os.environ['CUDA_VISIBLE_DEVICES'] = args.cuda  # 指定gpu
    checkpoint = torch.load('model_saved/{}/{}_model_best.pth.tar'.format(net_work,net_work))
    main(mode='test', args=args, checkpoint=checkpoint)
