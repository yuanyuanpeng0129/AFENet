##### System library #####
import os
from datetime import datetime
import tqdm
import socket
import numpy as np
##### pytorch library #####
import torch.nn as nn
from torch.utils.data import DataLoader
from tensorboardX import SummaryWriter
##### My own library #####
from dataprepare.dataloader import Yuanyuan_loader
from utils.loss import loss_builder
import utils.utils as u
from config import DefaultConfig
from models.Net import Res34UNet,ResNet34_DsSE,ResNet34_MsFF,AFENet
import torch
def val(args, model, dataloader_val):
    print('\n')
    print('Start Validation!')
    with torch.no_grad():  # 适用于推断阶段，不需要反向传播
        model.eval()  # 测试模式，自动把BN和DropOut固定住，用训练好的值
        tbar = tqdm.tqdm(dataloader_val, desc='\r')  # 添加一个进度提示信息，只需要封装任意的迭代器 tqdm(iterator)，desc进度条前缀
        total_Dice0 = [[]]# total_Dice中包含2个类别的dice列表
        total_PC=[]
        total_SE=[]
        total_SP=[]
        total_JS=[]
        # total_F1=[[]]
        total_PCC=[]
        total_Acc = []

        cur_predict_cube = []
        cur_label_cube = []
        counter = 0
        end_flag = False

        for i, (data, labels) in enumerate(tbar):  # i=300/batch_size=3
            # tbar.update()
            if torch.cuda.is_available() and args.use_gpu:
                data = data.cuda()
                label = labels[0].cuda()  # val模式下labels返回一个元祖，[0]为tensor,bnhw，[1]为cube中包含slice张数int值20
            slice_num =args.batch_size
            # get RGB predict image
            predict = model(data)
            predict[predict<0.5]=0
            predict[predict>0.5]=1
            batch_size = predict.size()[0]  # 即n
            counter += batch_size
            if counter <= slice_num:  # cube拼接
                cur_predict_cube.append(predict)
                cur_label_cube.append(label)
                if counter == slice_num:  # slice_num整除batch_size
                    end_flag = True
                    counter = 0  # counter清0，开始下一个cube计数
            else:  # slice_num不能整除batch_size
                last = batch_size - (counter - slice_num)  # 当前batch size中有last张属于当前处理的cube
                last_p = predict[0:last]  # 属于当前处理的cube的预测和标签
                last_l = label[0:last]
                first_p = predict[last:]  # 属于下一个cube的预测和标签
                first_l = label[last:]
                cur_predict_cube.append(last_p)  # 当前处理的cube拼接
                cur_label_cube.append(last_l)
                end_flag = True
                counter = counter - slice_num  # counter累计到下一个cube的值

            if end_flag:  # 拼接完成，end_flag为True
                end_flag = False
                label_cube = torch.cat(cur_label_cube, dim=0)
                predict_cube = torch.cat(cur_predict_cube, dim=0)  # 在0维拼接，列表转为slice_num*h*w的tensor

                cur_predict_cube = []  # 当前处理的cube列表清空
                cur_label_cube = []
                if counter != 0:  # 处理累计到下一个cube的slice
                    cur_predict_cube.append(first_p)
                    cur_label_cube.append(first_l)

                assert len(args.cuda.split(',')) * predict_cube.size()[0] == slice_num
                Dice, true_label, Acc = u.eval_single_seg(predict_cube, label_cube,args.num_classes)  # 返回Dice列表, True_label列表中包含2个类别的像素数量，acc为标量值
                PCC = u.compute_PCC(predict_cube, label_cube)
                PC, SE, Jaccard, SP = u.compute_score(predict_cube, label_cube,n_class=args.num_classes)  #注意修改

                class_id=0
                total_Dice0[class_id].append(Dice[class_id])
                total_SE.append(SE)
                total_PC.append(PC)
                total_JS.append(Jaccard)
                total_SP.append(SP)
                #total_F1[class_id].append(F1[class_id])
                total_PCC.append(PCC)# 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                total_Acc.append(Acc)

                len0 = len(total_Dice0[0]) if len(total_Dice0[0]) != 0 else 1
                dice = sum(total_Dice0[0]) / len0
                se0 = sum(total_SE) / len(total_SE)
                pc0 = sum(total_PC) / len(total_PC)
                sp0 = sum(total_SP) / len(total_SP)
                js0 = sum(total_JS) / len(total_JS)
                # f10 = sum(total_F1[0]) / len(total_SP[0])
                pcc0 = sum(total_PCC) / len(total_PCC)
                acc = sum(total_Acc) / len(total_Acc)
                tbar.set_description(
                    ' Dice: %.3f, Acc: %.3f, SE0:%.3f,  SP0:%.3f, JS0: %.3f, PC0: %.3f' % (
                    dice, acc,se0,sp0,js0,pc0))
                if i == tbar.total-1:
                    print('Dice:', dice)
                    print('Acc:', acc)
        checkpoint_dir = args.save_model_path
        if not os.path.exists(checkpoint_dir):
            os.makedirs(checkpoint_dir)
        with open(os.path.join(checkpoint_dir, '{}_dice.txt'.format(args.net_work)), 'a+') as f:
            f.write('Dice:' + str(dice) + ',')
            f.write('Acc:' + str(acc) + ',')
            f.write('SE0:' + str(se0) + ',')
            f.write('SP0:' + str(sp0) + ',')
            f.write('JS0:' + str(js0) + ',')
            f.write('PC0:' + str(pc0) + ',')
            f.write('PCC0:' + str(pcc0) + ',')
            f.write('\n')

    return dice,acc,se0,sp0,js0,pc0,pcc0


def train(args, model, optimizer, criterion, dataloader_train, dataloader_val, writer):
    step = 0
    best_dice = 0.0

    for epoch in range(args.num_epochs):
        lr = u.adjust_learning_rate(args, optimizer, epoch)  # 随着epoch更新学习率
        model.train()  # 网络调整为训练状态，打开dropout和BN
        tq = tqdm.tqdm(total=len(dataloader_train) * args.batch_size)  # 进度条总迭代次数 len*batchsize
        tq.set_description('epoch %d, lr %f' % (epoch, lr))  # 设置修改进度条的前缀内容
        loss_record = []
        train_loss = 0.0
        for i, (data, label) in enumerate(dataloader_train):  # i= 14*128/4= 448
            #print(np.sum(np.sum(np.sum(label))))
            if torch.cuda.is_available() and args.use_gpu:
                data = data.cuda()
                label = label.cuda()  # 索引值格式为long
            optimizer.zero_grad()  # 根据backward()函数的计算，当网络参量反馈时梯度是被积累的而不是被替换掉；因此在每一个batch时设置一遍zero_grad将梯度清零
            main_out = model(data)  # 前向传播
            #print("main_out.shape =========== {}".format(main_out.shape))
            #print("label.shape =========== {}".format(label.shape))
            loss_aux = criterion[2](main_out, label.float())#BCELoss
            loss_main = criterion[1](main_out, label)#DiceLoss
            loss = loss_main + loss_aux
            loss.backward()  # 反向传播回传损失，计算梯度（loss为一个零维的标量）
            optimizer.step()  # optimizer基于反向梯度更新网络参数空间，因此当调用optimizer.step()的时候应当是loss.backward()后
            tq.update(args.batch_size)  # 进度条每次更新batch_size个进度
            train_loss += loss.item()  # 使用.item()可以从标量中获取Python数字
            tq.set_postfix(loss='%.6f' % (train_loss / (i + 1)))  # 设置进度条后缀，显示之前所有loss的平均
            step += 1
            if step%10==0:
                writer.add_scalar('Train/loss_step', loss, step)
            loss_record.append(loss.item())  # loss_record包含所有loss的列表
        tq.close()
        loss_train_mean = np.mean(loss_record)  # 此次训练epoch的448个Loss的平均值
        writer.add_scalar('Train/loss_epoch', float(loss_train_mean),
                          epoch)  # 每一折的每个epoch记录一次平均loss和epoch到日志
        print('loss for train : %f' % (loss_train_mean))
        checkpoint_dir = args.save_model_path
        if not os.path.exists(checkpoint_dir):
            os.makedirs(checkpoint_dir)
        if epoch % args.validation_step == 0:  # 每训练validation_step个epoch进行一次验证，此时为1
            with open(os.path.join(checkpoint_dir,'dice.txt'), 'a+') as f:
                f.write('EPOCH:' + str(epoch) + ', ')
                f.write('lr:' + str(lr) + ', ')
                f.write('loss:'+str(loss_train_mean)+',')

            Dice,  Acc , Sensitivity, Specificity,jaccard, PC, PCC= val(args, model, dataloader_val)
            writer.add_scalar('Valid/Dice_val', Dice, epoch)
            writer.add_scalar('Valid/Acc_val', Acc, epoch)
            writer.add_scalar('Valid/Sensitivity_val', Sensitivity, epoch)
            writer.add_scalar('Valid/Specificity_val', Specificity, epoch)
            writer.add_scalar('Valid/Jaccard_val', jaccard, epoch)
            writer.add_scalar('Valid/PC_val', PC, epoch)
            writer.add_scalar('Valid/PCC_val', PCC, epoch)


            is_best = Dice > best_dice  # is_best为bool，以验证集平均dice为指标判断是否为best
            best_dice = max(best_dice, Dice)  # 更新当前best dice

            if is_best:
                checkpoint_dir = args.save_model_path
                if not os.path.exists(checkpoint_dir):
                    os.makedirs(checkpoint_dir)
                with open(os.path.join(checkpoint_dir, 'best_dice.txt'), 'a+') as f:
                    f.write('Epoch:' + str(epoch) + ':')
                    f.write('Dice:' + str(Dice) + ',')
                    f.write('Acc:' + str(Acc) + ',')
                    f.write('SE0:' + str(Sensitivity) + ',')
                    f.write('SP0:' + str(Specificity) + ',')
                    f.write('JS0:' + str(jaccard) + ',')
                    f.write('PC0:' + str(PC) + ',')
                    f.write('PCC0:' + str(PCC) + ',')
                    f.write('\n')
                print('===> Saving models...')
                state = {
                    'net': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch,  # 将epoch一并保存
                    'best_dice': best_dice
                }
                torch.save(state,checkpoint_dir + '/'+args.best_model)

            #在保存用于推理或恢复训练的通用检查点时，必须保存模型的state_dict，优化器的state_dict也是很重要，因为它包含缓冲区和参数，要保存多个组件将它们组织在字典中，并使用torch.save()序列化字典。
            u.save_checkpoint({
                    'epoch': epoch + 1,
                    'best_dice': best_dice,
                    'optimizer': optimizer.state_dict(),
                    'dice_epoch': Dice,
                    'state_dict': model.state_dict(),
                    }, best_dice, epoch, is_best, args.save_model_path,args.net_work,args.save_every_checkpoint, checkpoint_dir)

def main(mode='train', args=None, writer=None):
    # set gpu
    os.environ['CUDA_VISIBLE_DEVICES'] = args.cuda  # 指定gpu
    # create dataset and dataloader
    dataset_path = os.path.join(args.data, args.dataset)
    dataset_train = Yuanyuan_loader(dataset_path,scale=(args.crop_height, args.crop_width), mode='train')
    print("args.batch_size ========= {}".format(args.batch_size))
    dataloader_train = DataLoader(
        dataset_train,  # 加载的数据集(Dataset对象),dataloader是一个可迭代的对象，可以像使用迭代器一样使用
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,  # 使用多进程加载的进程数，0代表不使用多进程
        pin_memory=True,  # 是否将数据保存在pin memory区，pin memory中的数据转到GPU会快一些
        drop_last=True  # dataset中的数据个数可能不是batch_size的整数倍，drop_last为True会将多出来不足一个batch的数据丢弃
    )

    dataset_val = Yuanyuan_loader(dataset_path,scale=(args.crop_height, args.crop_width), mode='val')
    dataloader_val = DataLoader(
        dataset_val,
        # this has to be 1
        batch_size=args.batch_size,  # 只选择1块gpu，batchsize=1
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False
    )

    model = AFENet().cuda()
    print('Model have been loaded!,you chose the ' + args.net_work + '!')
    #if torch.cuda.is_available() and args.use_gpu:
        #model = torch.nn.DataParallel(model).cuda()  # torch.nn.DataParallel是支持并行GPU使用的模型包装器，并将模型放到cuda上

    # load trained model for test
    if args.trained_model_path and args.mode == 'test':  # 测试时加载训练好的模型
        print("=> loading trained model '{}'".format(args.trained_model_path))
        checkpoint = torch.load(
            args.trained_model_path)  # torch.load：使用pickle unpickle工具将pickle的对象文件反序列化为内存，包括参数、优化器、epoch等
        model.load_state_dict(checkpoint['state_dict'])  # torch.nn.Module.load_state_dict:使用反序列化状态字典加载model’s参数字典
        print('Done!')

    #optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)  # 初始化优化器，构造一个optimizer对象
    optimizer = torch.optim.Adam(model.parameters(),lr = args.lr,amsgrad=True,weight_decay=args.weight_decay)

    # set the loss criterion
    criterion = loss_builder(args.loss_type, args.multitask)

    if mode == 'train':
        train(args, model, optimizer, criterion, dataloader_train, dataloader_val, writer)
if __name__ == '__main__':
    args = DefaultConfig()  # 配置设置
    torch.set_num_threads(1)
    modes = args.mode
    if modes == 'train':
        current_time = datetime.now().strftime('%b%d_%H-%M-%S')  # 程序开始运行的时间
        log_dir = os.path.join(args.log_dirs,
                               args.net_work + '_' + '_' + current_time + '_' + socket.gethostname())  # 获取当前计算节点名称cu01
        if not os.path.exists(os.path.dirname(log_dir)):  # 创建目录文件夹
            os.makedirs(os.path.dirname(log_dir))
        writer = SummaryWriter(log_dir=log_dir)  # 创建writer object，log会被存入指定文件夹，writer.add_scalar保存标量值到log

        main(mode='train', args=args, writer=writer)
