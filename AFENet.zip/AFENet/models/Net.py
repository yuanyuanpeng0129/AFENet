import torch
import torch.nn as nn
import torch.nn.functional as F
from models.resnet import resnet34
from functools import partial

nonlinearity = partial(F.relu, inplace=True)

class DsSE(nn.Module):
    def __init__(self, r,in_dim,output_channel):
        super(DsSE, self).__init__()
        self.conv = nn.Conv2d(in_dim*2, output_channel, kernel_size=1, stride=1)
        self.upsample = nn.Upsample(scale_factor=2, mode='bilinear')
        self.query_conv = nn.Conv2d(output_channel, output_channel // r, kernel_size=1)
        self.key_conv = nn.Conv2d(output_channel, output_channel // r, kernel_size=1)
        self.value_conv = nn.Conv2d(output_channel, output_channel, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.softmax = nn.Softmax(dim=-1)
        
    def forward(self, x,x2):
        x = self.conv(x)
        x1 = self.upsample(x)
        m_batchsize, C, height, width = x1.size()
        proj_query = self.query_conv(x1).view(m_batchsize, -1, width * height).permute(0, 2, 1)
        proj_key = self.key_conv(x2).view(m_batchsize, -1, width * height)#C
        energy = torch.bmm(proj_query, proj_key)#B*C
        attention = self.softmax(energy)
        proj_value = self.value_conv(x2).view(m_batchsize, -1, width * height)#D

        out = torch.bmm(proj_value, attention.permute(0, 2, 1))#计算两个tensor的矩阵乘法,D*attention
        out = out.view(m_batchsize, C, height, width)
        out = self.gamma * out + x2
        
        return out   

class AFM(nn.Module):
    def __init__(self, reduction, channel, out_channel, stride):
        super(AFM, self).__init__()
        self.downsample = nn.Conv2d(channel, out_channel, kernel_size=1, stride=stride)
        self.ConvReluBN = nn.Sequential(
            nn.Conv2d(out_channel, channel//reduction, kernel_size=1, stride=1, padding=0, bias=False),
            nn.ReLU(inplace=True),
        )

        self.conv = nn.Conv2d(channel//reduction, out_channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        down = self.downsample(x)
        y = self.ConvReluBN(down)
        y = self.conv(y)
        p = self.sigmoid(y)
        out = torch.mul(down,p)
        return out,p

class AFM_1(nn.Module):
    def __init__(self, reduction, channel, out_channel):
        super(AFM_1, self).__init__()
        self.ConvReluBN = nn.Sequential(
            nn.Conv2d(out_channel, channel//reduction, kernel_size=1, stride=1, padding=0, bias=False),
            nn.ReLU(inplace=True),
        )

        self.conv = nn.Conv2d(channel//reduction, out_channel, kernel_size=1, stride=1, padding=0, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.ConvReluBN(x)
        y = self.conv(y)
        p = self.sigmoid(y)
        out = torch.mul(x,p)
        return out,p

class MsFF(nn.Module):
    def __init__(self, gama=1, beta=1):
        super(MsFF, self).__init__()
        self.AFM_2 = AFM(16,128, 512, 4)
        self.AFM_3 = AFM(16,256,512,2)
        self.AFM_4 = AFM_1(16,512, 512)
        self.gama = gama
        self.beta = beta
    
    def forward(self, x2,x3,x4):
        y2, p2 = self.AFM_2(x2)
        y3, p3 = self.AFM_3(x3)
        y4, p4 = self.AFM_4(x4)
        y = torch.mul((y2+y3),(1-p4))
        out = x4 + self.gama*y4 + self.beta*y

        return out

class DecoderBlock(nn.Module):
    def __init__(self, in_channels, n_filters):
        super(DecoderBlock, self).__init__()

        self.conv1 = nn.Conv2d(in_channels, in_channels // 4, 1)
        self.norm1 = nn.BatchNorm2d(in_channels // 4)
        self.relu1 = nonlinearity

        self.deconv2 = nn.ConvTranspose2d(in_channels // 4, in_channels // 4, 3, stride=2, padding=1, output_padding=1)
        self.norm2 = nn.BatchNorm2d(in_channels // 4)
        self.relu2 = nonlinearity

        self.conv3 = nn.Conv2d(in_channels // 4, n_filters, 1)
        self.norm3 = nn.BatchNorm2d(n_filters)
        self.relu3 = nonlinearity

    def forward(self, x):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.relu1(x)
        x = self.deconv2(x)
        x = self.norm2(x)
        x = self.relu2(x)
        x = self.conv3(x)
        x = self.norm3(x)
        x = self.relu3(x)
        return x

class Res34UNet(nn.Module):
    def __init__(self, in_channels=3, num_classes=1):
        super(Res34UNet, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4
        
        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x = self.firstmaxpool(x)
        e1 = self.encoder1(x)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)
        
        # Decoder
        d4 = self.decoder4(e4) + e3
        d3 = self.decoder3(d4) + e2
        d2 = self.decoder2(d3) + e1
        d1 = self.decoder1(d2)

        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)
        out = torch.sigmoid(out)

        return out
    
class ResNet34_DsSE(nn.Module):###best
    def __init__(self, in_channels=3, num_classes=1):
        super(ResNet34_DsSE, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.Skip1 = DsSE(16,64,64)
        self.encoder3 = resnet.layer3
        self.Skip2 = DsSE(16,128,128)
        self.encoder4 = resnet.layer4
        self.Skip3 = DsSE(16,256,256)
        
        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x_ = self.firstmaxpool(x)
        e1 = self.encoder1(x_)
        e2 = self.encoder2(e1)
        y1 = self.Skip1(e2,e1)
        e3 = self.encoder3(e2)
        y2 = self.Skip2(e3,e2)
        e4 = self.encoder4(e3)
        y3 = self.Skip3(e4,e3)
        
        # Decoder
        d4 = self.decoder4(e4) + y3
        d3 = self.decoder3(d4) + y2
        d2 = self.decoder2(d3) + y1
        d1 = self.decoder1(d2)
      
        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)
        out = torch.sigmoid(out)

        return out

class ResNet34_MsFF(nn.Module):###best
    def __init__(self, in_channels=3, num_classes=1):
        super(ResNet34_MsFF, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.encoder3 = resnet.layer3
        self.encoder4 = resnet.layer4
        self.MsFF = MsFF()
        
        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x_ = self.firstmaxpool(x)
        e1 = self.encoder1(x_)
        e2 = self.encoder2(e1)
        e3 = self.encoder3(e2)
        e4 = self.encoder4(e3)
        e4 = self.MsFF(e2,e3,e4)
        
        # Decoder
        d4 = self.decoder4(e4) + e3
        d3 = self.decoder3(d4) + e2
        d2 = self.decoder2(d3) + e1
        d1 = self.decoder1(d2)
      
        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)
        out = torch.sigmoid(out)

        return out

class AFENet(nn.Module):###best
    def __init__(self, in_channels=3, num_classes=1):
        super(AFENet, self).__init__()

        filters = [64, 128, 256, 512]
        resnet = resnet34(pretrained=True)
        self.firstconv = resnet.conv1
        self.firstbn = resnet.bn1
        self.firstrelu = resnet.relu
        self.firstmaxpool = resnet.maxpool
        self.encoder1 = resnet.layer1
        self.encoder2 = resnet.layer2
        self.Skip1 = DsSE(16,64,64)
        self.encoder3 = resnet.layer3
        self.Skip2 = DsSE(16,128,128)
        self.encoder4 = resnet.layer4
        self.Skip3 = DsSE(16,256,256)
        self.MsFF = MsFF()
        
        self.decoder4 = DecoderBlock(filters[3], filters[2])
        self.decoder3 = DecoderBlock(filters[2], filters[1])
        self.decoder2 = DecoderBlock(filters[1], filters[0])
        self.decoder1 = DecoderBlock(filters[0], filters[0])

        self.finaldeconv1 = nn.ConvTranspose2d(filters[0], 32, 4, 2, 1)
        self.finalrelu1 = nonlinearity
        self.finalconv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.finalrelu2 = nonlinearity
        self.finalconv3 = nn.Conv2d(32, num_classes, 3, padding=1)

    def forward(self, x):
        # Encoder
        x = self.firstconv(x)##(64,128,128)
        x = self.firstbn(x)
        x = self.firstrelu(x)
        x_ = self.firstmaxpool(x)##(64,64,64)
        e1 = self.encoder1(x_)##(64,64,64)
        e2 = self.encoder2(e1)##(128,32,32)
        y1 = self.Skip1(e2,e1)##(128,32,32)
        e3 = self.encoder3(e2)##(256,16,16)
        y2 = self.Skip2(e3,e2)##(256,16,16)
        e4 = self.encoder4(e3)##(512,8,8)
        y3 = self.Skip3(e4,e3)##(512,8,8)
        e4 = self.MsFF(e2,e3,e4)##(512,8,8)
        
        # Decoder
        d4 = self.decoder4(e4) + y3
        d3 = self.decoder3(d4) + y2
        d2 = self.decoder2(d3) + y1
        d1 = self.decoder1(d2)
      
        out = self.finaldeconv1(d1)
        out = self.finalrelu1(out)
        out = self.finalconv2(out)
        out = self.finalrelu2(out)
        out = self.finalconv3(out)
        out = torch.sigmoid(out)

        return out

