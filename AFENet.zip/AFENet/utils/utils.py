# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import os.path as osp
import imgaug as ia
import random
import shutil
import math
from config import DefaultConfig


def setup_seed(seed=1234):
     torch.manual_seed(seed)                                                   #为CPU设置种子用于生成随机数，以使得结果是确定的
     torch.cuda.manual_seed(seed)                                              #为当前GPU设置随机种子
     torch.cuda.manual_seed_all(seed)                                          #torch.cuda.manual_seed_all()为多个GPU设置种子
     np.random.seed(seed)
     random.seed(seed)
     ia.seed(seed)
     
     cudnn.benchmark = False
     torch.backends.cudnn.deterministic = True
    
class AverageMeter(object):
    '''计算并存储val平均值和当前值'''
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def save_checkpoint(state,best_dice,epoch,is_best,save_model_path,net_work,save_every_checkpoint,checkpoint_dir):
    '''
    本函数：可保存所有模型，或保存每一次best更新，latest
    deepseg：保存所有模型，latest，一个best
    '''
    checkpoint_latest = osp.join(checkpoint_dir, 'checkpoint_latest.pth.tar')
    torch.save(state, checkpoint_latest)                                       #保存当前最新predict为latest model
    if is_best:
        print("Get Better top1 : %s"%(state["best_dice"]))                                                                #best_pred更新，另外保存一份此时的latest model为best_pred的模型
#        shutil.copyfile(checkpoint_latest, osp.join(checkpoint_dir,'model_{:03d}_{:.4f}.pth.tar'.format((epoch + 1),best_dice)))
        shutil.copyfile(checkpoint_latest, osp.join(checkpoint_dir,'{}_model_best.pth.tar'.format(str(net_work))))
    if save_every_checkpoint:
        if (epoch + 1) % 1 == 0:                                               #每隔多少epoch保存一次模型
            shutil.copyfile(checkpoint_latest, osp.join(checkpoint_dir,'model_{:03d}.pth.tar'.format(epoch + 1)))
        
def adjust_learning_rate(opt, optimizer, epoch):                        
    """
    将学习速率设置为初始LR经过每30个epoch衰减10% (step = 30)
    """
    if opt.lr_mode == 'step':
        lr = opt.lr * (0.1 ** (epoch // opt.step))
    elif opt.lr_mode == 'poly':
        lr = opt.lr * (1 - epoch / opt.num_epochs) ** 0.9
    elif opt.lr_mode == 'normal':
        lr = opt.lr
    else:
        raise ValueError('Unknown lr mode {}'.format(opt.lr_mode))

    for param_group in optimizer.param_groups:                                 #可以为一个网络设置多个优化器，每个优化器对应一个字典包括参数组及其对应的学习率,动量等等，optimizer.param_groups是由所有字典组成的列表
        param_group['lr'] = lr                                                 #动态修改学习率
    return lr

def save_dice_single(is_best, filename='dice_single.txt'):
    '''
    is_best更新，另外保存一份此时的dice_single.txt为dice_best.txt
    '''
    if is_best:
        shutil.copyfile(filename, 'dice_best.txt')

def compute_score(predicts, label, forground=1,n_class=2):
    '''
    计算二分类Dice,Precsion,Recall,Jaccard，返回其值（不加smooth）
    输入原标签0123
    可算slice与cube

    overlap=0的情况：
        gt和predict无交集，正常计算各指标为0
        gt无 predict有，recall为Nan，输出0
        gt有 predict无，precsion为Nan,输出0
        gt无 predict无，全部为Nan,输出0
    '''
    assert (predicts.shape == label.shape)
    overlap = ((predicts == 1) * (label == 1)).sum().float()  # TP
   
    if (overlap > 0):
        for i in range(predicts.shape[1]):
            #overlap = ((predicts[:, i, :, :] == 1) * (label[:, i, :, :] == 1)).sum().float()  # TP
            # dice = 2 * overlap / ((predicts[:,i,:,:] == 1).sum() + (label[:,i,:,:] == 1).sum()).float()
            PC=overlap / (predicts[:,i,:,:] == 1).sum().float()
            SE=overlap / (label[:,i,:,:] == 1).sum().float()
            Jaccard=overlap / ((predicts[:,i,:,:] == 1).sum() + (label[:,i,:,:] == 1).sum() - overlap).float()
            SP=((predicts[:,i,:,:] == 0) * (label[:,i,:,:] == 0)).sum().float()/(label[:,i,:,:] == 0).sum().float()

            #F1 .append(2*overlap / (label[:,i,:,:] == 1).sum().float()*overlap / (predicts[:,i,:,:] == 1).sum().float()/(overlap / (label[:,i,:,:] == 1).sum() + overlap / (predicts[:,i,:,:] == 1).sum().float() + 1e-6))
        return PC, SE, Jaccard, SP
    else:
        return 0, 0, 0, 0



def eval_seg(predict, gt, forground = 1):
    '''
    计算多分类Dice,Precsion,Recall,Jaccard，分为4次二分类计算，背景也包括在内（不加smooth）
    输入one-hot编码
    计算slice，不计算cube
    '''
    assert(predict.shape == gt.shape)
    Dice = 0
    Precsion = 0
    Recall = 0
    Jaccard = 0
    n = predict.shape[0]
    for i in range(n):
        dice,precsion,recall,jaccard = compute_score(predict[i],gt[i])
        Dice += dice
        Precsion += precsion
        Recall += recall
        Jaccard += jaccard

    return Dice/n,Precsion/n,Recall/n,Jaccard/n

def compute_PCC(predicts,label):
    assert(predicts.shape==label.shape)

    i=0
    n = predicts.shape[0]*predicts.shape[2]*predicts.shape[3]
    TP = ((predicts[:,i,:,:]==1)*(label[:,i,:,:]==1)).sum()
    sum_x = predicts[:,i,:,:].sum()
    sum_y = label[:,i,:,:].sum()
    sum_x2 = predicts[:,i,:,:].pow(2).sum()
    sum_y2 = label[:,i,:,:].pow(2).sum()
    molecular = TP-(float(sum_x)*float(sum_y)/n)
    denominator = ((sum_x2-float(sum_x2**2)/n)*(sum_y2-float(sum_y2**2)/n)).sqrt()
    PCC=molecular/denominator

    return PCC

def compute_segment_score(ret_segmentation,cubes=5):
    '''
    计算所有cube的平均指标，不计算金标准Nan情况，该类有几个cube分母为几
    ret_segmentation列表长度为cube数，其元素也是列表[cube_dice0,cube_dice1,cube_dice2,cube_dice3]
    最终的is_best评判标准！！！！
    '''
    IRF_segementation, SRF_segementation, PED_segementation = 0.0, 0.0, 0.0
    n1, n2, n3 = 0, 0, 0
    for i in range(cubes):
        if not math.isnan(ret_segmentation[i][1]):
            IRF_segementation += ret_segmentation[i][1]
            n1 += 1
        if not math.isnan(ret_segmentation[i][2]):
            SRF_segementation += ret_segmentation[i][2]
            n2 += 1
        if not math.isnan(ret_segmentation[i][3]):
            PED_segementation += ret_segmentation[i][3]
            n3 += 1

    IRF_segementation /= n1
    SRF_segementation /= n2
    PED_segementation /= n3
    avg_segmentation = (IRF_segementation + SRF_segementation + PED_segementation) / 3

    return avg_segmentation,IRF_segementation,SRF_segementation,PED_segementation
       
def eval_single_seg(predict, target,classes=1):
    pred_seg = predict.data.cpu().numpy().astype(dtype=np.int)

    label_seg = target.data.cpu().numpy().astype(dtype=np.int)
    assert(pred_seg.shape == label_seg.shape)

    acc=(pred_seg==label_seg).sum()/(pred_seg.shape[0]*pred_seg.shape[2]*pred_seg.shape[3])

    Dice=[]
    True_label=[]
    overlap=((pred_seg==classes)*(label_seg==classes)).sum()
    union=(pred_seg==classes).sum()+(label_seg==classes).sum()
    Dice.append((2*overlap+1e-5)/(union+1e-5))
    True_label.append((label_seg==classes).sum())
    
    return Dice,True_label,acc

